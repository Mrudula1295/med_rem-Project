const CACHE_NAME = 'medreminder-v1';
const ASSETS = [
    '/',
    '/index.html',
    '/dashboard.html',
    '/login.html',
    '/signup.html',
    '/add-medicine.html',
    '/health-records.html',
    '/css/style.css',
    '/js/api.js',
    '/js/auth.js',
    '/js/main.js'
];

self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
    );
});

self.addEventListener('fetch', event => {
    if (event.request.method === 'GET' && !event.request.url.includes('/api/')) {
        event.respondWith(
            fetch(event.request).catch(() => caches.match(event.request))
        );
    }
});

self.addEventListener('push', event => {
    const data = event.data ? event.data.json() : {};
    const title = data.title || 'Medicine Reminder';
    const options = {
        body: data.body || 'Time to take your medicine!',
        icon: data.icon || 'https://cdn-icons-png.flaticon.com/512/2966/2966327.png',
        image: data.image || null,
        badge: 'https://cdn-icons-png.flaticon.com/512/2966/2966327.png',
        data: data,
        actions: [
            { action: 'taken', title: '✓ Mark as Taken' },
            { action: 'snooze', title: '⏰ Remind Again' }
        ],
        requireInteraction: true
    };
    event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', event => {
    event.notification.close();
    const action = event.action;
    const data = event.notification.data;

    if (action === 'taken') {
        fetch(`http://localhost:8080/api/reminders/mark-taken/${data.reminderId}`, { method: 'POST' });
    } else if (action === 'snooze') {
        fetch(`http://localhost:8080/api/reminders/snooze/${data.reminderId}`, { method: 'POST' });
    } else {
        clients.openWindow('/dashboard.html');
    }
});
