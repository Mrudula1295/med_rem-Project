document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();
            
            try {
                const btn = loginForm.querySelector('button');
                btn.textContent = 'Logging in...';
                btn.disabled = true;

                const user = await fetchAPI('/auth/login', 'POST', { username, password });
                localStorage.setItem('user', JSON.stringify(user));
                window.location.href = 'dashboard.html';
            } catch (err) {
                const btn = loginForm.querySelector('button');
                btn.textContent = 'Login';
                btn.disabled = false;
                alert('Login failed: ' + err.message);
            }
        });
    }

    if (signupForm) {
        signupForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = signupForm.username.value;
            const password = signupForm.password.value;
            
            try {
                const btn = signupForm.querySelector('button');
                btn.textContent = 'Creating account...';
                btn.disabled = true;

                const user = await fetchAPI('/auth/signup', 'POST', { username, password });
                localStorage.setItem('user', JSON.stringify(user));
                window.location.href = 'dashboard.html';
            } catch (err) {
                const btn = signupForm.querySelector('button');
                btn.textContent = 'Sign Up';
                btn.disabled = false;
                alert('Signup failed: ' + err.message);
            }
        });
    }
});
