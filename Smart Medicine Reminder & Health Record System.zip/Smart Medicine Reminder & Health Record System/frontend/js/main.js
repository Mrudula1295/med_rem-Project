// main.js - Core application logic for dashboard, medicines, and records

async function loadDashboard() {
    const user = getUser();
    if (!user) return;

    try {
        const [medicines, reminders] = await Promise.all([
            fetchAPI(`/medicines/list/${user.id}`),
            fetchAPI(`/reminders/user/${user.id}`)
        ]);

        renderMedicines(medicines);
        renderReminders(reminders, medicines);
        
        if ("Notification" in window && Notification.permission === "default") {
            Notification.requestPermission();
        }

        
        // Setup local polling for reminders checking (if SW push is not available)
        setInterval(() => checkLocalReminders(reminders, medicines), 60000);
        checkLocalReminders(reminders, medicines);
    } catch (e) {
        showToast('Error loading dashboard: ' + e.message);
    }
}

function renderMedicines(medicines) {
    const grid = document.getElementById('medicinesGrid');
    if (!grid) return;

    grid.innerHTML = '';
    if (medicines.length === 0) {
        grid.innerHTML = '<div class="empty-state" style="grid-column: 1 / -1;"><h3>No Medicines Added</h3><p>Click "+ Add Medicine" to get started.</p></div>';
        return;
    }

    medicines.forEach(med => {
        const div = document.createElement('div');
        div.className = 'card';
        div.innerHTML = `
            <img src="${getBackendUrl(med.imagePath)}" alt="${med.name}" onerror="this.src='https://via.placeholder.com/300x200?text=No+Image'">
            <div class="card-title">${med.name}</div>
            <div class="actions">
                <button class="btn-small btn-danger" onclick="deleteMedicine(${med.id})">Delete</button>
            </div>
        `;
        grid.appendChild(div);
    });
}

function renderReminders(reminders, medicines) {
    const grid = document.getElementById('remindersGrid');
    if (!grid) return;

    grid.innerHTML = '';
    const pendingReminders = reminders.filter(r => r.status === 'PENDING' || r.status === 'SNOOZED');
    
    if (pendingReminders.length === 0) {
        grid.innerHTML = '<div class="empty-state" style="grid-column: 1 / -1;"><h3>All Caught Up!</h3><p>You have no pending reminders.</p></div>';
        return;
    }

    pendingReminders.forEach(reminder => {
        const medId = reminder.medicine ? (typeof reminder.medicine === 'object' ? reminder.medicine.id : reminder.medicine) : null;
        const med = medicines.find(m => m.id === medId) || reminder.medicine || { name: 'Unknown', imagePath: null };
        let timeStr = new Date(reminder.nextReminderTime).toLocaleString();
        
        const div = document.createElement('div');
        div.className = 'card';
        div.innerHTML = `
            <img src="${getBackendUrl(med.imagePath)}" alt="${med.name}" onerror="this.src='https://via.placeholder.com/300x200?text=No+Image'">
            <div class="card-title">${med.name}</div>
            <div class="card-meta">
                <span class="badge ${reminder.status.toLowerCase()}">${reminder.status}</span>
                <span>${timeStr}</span>
            </div>
            <div class="actions">
                <button class="btn-small btn-success" onclick="markTaken(${reminder.id})">✓ Taken</button>
                <button class="btn-small btn-outline" onclick="snooze(${reminder.id})">⏰ Snooze</button>
                <button class="btn-small btn-danger" onclick="deleteReminder(${reminder.id})">Delete</button>
            </div>
        `;
        grid.appendChild(div);
    });
}

async function markTaken(reminderId) {
    try {
        await fetchAPI(`/reminders/mark-taken/${reminderId}`, 'POST', null, true);
        showToast('Marked as taken!');
        loadDashboard();
    } catch (e) {
        showToast('Error: ' + e.message);
    }
}

async function snooze(reminderId) {
    try {
        await fetchAPI(`/reminders/snooze/${reminderId}`, 'POST', null, true);
        showToast('Reminder snoozed for 5 minutes.');
        loadDashboard();
    } catch (e) {
        showToast('Error: ' + e.message);
    }
}

async function deleteMedicine(medId) {
    if(!confirm("Are you sure you want to delete this medicine?")) return;
    try {
        console.log(`Attempting to delete medicine ${medId}`);
        await fetchAPI(`/medicines/delete/${medId}`, 'DELETE', null, true);
        showToast('Medicine deleted.');
        loadDashboard();
    } catch (e) {
        showToast('Error: ' + e.message);
    }
}

async function deleteReminder(reminderId) {
    if(!confirm("Are you sure you want to delete this reminder?")) return;
    try {
        console.log(`Attempting to delete reminder ${reminderId}`);
        await fetchAPI(`/reminders/delete/${reminderId}`, 'DELETE', null, true);
        showToast('Reminder deleted.');
        loadDashboard();
    } catch (e) {
        showToast('Error: ' + e.message);
    }
}

// Local Polling for reminders
function checkLocalReminders(reminders, medicines) {
    const now = new Date();
    const pendingReminders = reminders.filter(r => r.status === 'PENDING' || r.status === 'SNOOZED');
    
    pendingReminders.forEach(reminder => {
        const reminderTime = new Date(reminder.nextReminderTime);
        if (now >= reminderTime) {
            const med = medicines.find(m => m.id === reminder.medicine.id) || reminder.medicine;
            if (Notification.permission === 'granted') {
                new Notification('Medicine Reminder', {
                    body: `Time to take ${med.name}!`,
                    icon: getBackendUrl(med.imagePath),
                    requireInteraction: true
                });
            } else if (Notification.permission !== 'denied') {
                Notification.requestPermission().then(permission => {
                    if (permission === 'granted') {
                        new Notification('Medicine Reminder', {
                            body: `Time to take ${med.name}!`,
                            icon: getBackendUrl(med.imagePath),
                            requireInteraction: true
                        });
                    }
                });
            }
        }
    });
}

// --- Add Medicine Logic --- //
const addMedicineForm = document.getElementById('addMedicineForm');
if (addMedicineForm) {
    addMedicineForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const user = getUser();
        const fileInput = document.getElementById('medImage');
        const medName = document.getElementById('medName').value;
        const medReminderTime = document.getElementById('medReminderTime').value;

        const formData = new FormData();
        formData.append('userId', user.id);
        formData.append('name', medName);
        if (fileInput.files[0]) {
            formData.append('image', fileInput.files[0]);
        }

        try {
            const submitBtn = document.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.textContent = 'Saving...';

            const newMed = await fetchAPI('/medicines/add', 'POST', formData, true);
            
            // Set first reminder
            const rFormData = new URLSearchParams();
            rFormData.append('medicineId', newMed.id);
            rFormData.append('reminderTime', medReminderTime);
            
            await fetchAPI('/reminders/set', 'POST', rFormData, true);
            
            showToast('Medicine and Reminder added successfully!');
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1000);
        } catch (err) {
            document.querySelector('button[type="submit"]').disabled = false;
            document.querySelector('button[type="submit"]').textContent = 'Save Medicine & Reminder';
            showToast('Failed: ' + err.message);
        }
    });
}

// --- Records Logic --- //
async function loadRecords() {
    const user = getUser();
    if (!user) return;
    
    try {
        const records = await fetchAPI(`/records/list/${user.id}`);
        const grid = document.getElementById('recordsList');
        if (!grid) return;

        grid.innerHTML = '';
        if (records.length === 0) {
            grid.innerHTML = '<div class="empty-state" style="grid-column: 1 / -1;"><h3>No Records Found</h3></div>';
            return;
        }

        records.forEach(rec => {
            const div = document.createElement('div');
            div.className = 'card';
            const filePath = rec.filePath || '';
            const isPdf = filePath.toLowerCase().endsWith('.pdf');
            const preview = (isPdf && filePath) ? '📄 PDF Document' : `<img src="${getBackendUrl(rec.filePath)}" onerror="this.src='https://via.placeholder.com/300x200?text=No+Image'">`;
            
            div.innerHTML = `
                ${isPdf ? `<div style="height:180px; background:rgba(0,0,0,0.2); display:flex; align-items:center; justify-content:center; font-size:1.5rem; border-radius:12px; margin-bottom:16px;">${preview}</div>` : preview}
                <div class="card-title">${rec.title}</div>
                <div class="actions">
                    <a href="${getBackendUrl(rec.filePath)}" target="_blank" class="btn-small btn-outline">View File</a>
                    <button class="btn-small btn-danger" onclick="deleteRecord(${rec.id})">Delete</button>
                </div>
            `;
            grid.appendChild(div);
        });
    } catch (e) {
        showToast('Error loading records: ' + e.message);
    }
}

const uploadRecordForm = document.getElementById('uploadRecordForm');
if (uploadRecordForm) {
    uploadRecordForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const user = getUser();
        const fileInput = document.getElementById('recordFile');
        const recordTitle = document.getElementById('recordTitle').value;

        const formData = new FormData();
        formData.append('userId', user.id);
        formData.append('title', recordTitle);
        if (fileInput.files[0]) {
            formData.append('file', fileInput.files[0]);
        }

        try {
            const submitBtn = document.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.textContent = 'Uploading...';

            await fetchAPI('/records/upload', 'POST', formData, true);
            
            showToast('Record uploaded successfully!');
            submitBtn.disabled = false;
            submitBtn.textContent = 'Upload Record';
            uploadRecordForm.reset();
            document.getElementById('recordFileNameDisplay').innerText = 'Click to select file';
            loadRecords(); // Refresh list
        } catch (err) {
            document.querySelector('button[type="submit"]').disabled = false;
            document.querySelector('button[type="submit"]').textContent = 'Upload Record';
            showToast('Failed: ' + err.message);
        }
    });
}

async function deleteRecord(recordId) {
    if(!confirm("Are you sure you want to delete this record?")) return;
    try {
        console.log(`Attempting to delete record ${recordId}`);
        await fetchAPI(`/records/delete/${recordId}`, 'DELETE', null, true);
        showToast('Record deleted.');
        loadRecords();
    } catch (e) {
        showToast('Error: ' + e.message);
    }
}
